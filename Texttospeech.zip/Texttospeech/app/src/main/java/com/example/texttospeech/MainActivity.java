package com.example.texttospeech;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener{
    EditText editText;
    Button speak_Button;
    TextToSpeech tts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.txt);
        speak_Button=findViewById(R.id.speak);
        tts=new TextToSpeech(MainActivity.this,this);
        speak_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String station=editText.getText().toString();
                String text="Next Station is"+station+"Please get there on time you stupid son of a bitch";
                tts.speak(text,TextToSpeech.QUEUE_FLUSH,null);
            }
        });
    }

    @Override
    public void onInit(int status) {

    }
}
